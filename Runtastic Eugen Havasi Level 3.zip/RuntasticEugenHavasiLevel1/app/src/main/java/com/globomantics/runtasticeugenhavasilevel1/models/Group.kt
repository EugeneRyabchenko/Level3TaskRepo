package com.globomantics.runtasticeugenhavasilevel1.models

data class Competition(
    val groups: List<Group>
)

data class Group(
    val group_id: Int,
    val group_name: String,
    val members: List<Member>
)

data class Member(
    val member_id: Int,
    val member_first_name: String,
    val member_last_name: String,
    val member_distance_covered: Int,
    val member_active_minutes: Float
)





