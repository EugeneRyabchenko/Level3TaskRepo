package com.globomantics.runtasticeugenhavasilevel1

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.globomantics.runtasticeugenhavasilevel1.models.Member
import com.squareup.picasso.Picasso

class MyMemberRecyclerViewAdapter(
        private val act: FragmentActivity?,
        private val members: List<Member>
) : RecyclerView.Adapter<MyMemberRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.fragment_member, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val member = members[position]
        holder.memberId.text = member.member_id.toString()
        holder.memberFirstName.text = member.member_first_name
        holder.memberLastName.text = member.member_last_name
        val memberPictureUrl: String = "http://download.runtastic.com/meetandcode/mobile_and_web_2016/images/members/"
        Picasso.get()
                .load(memberPictureUrl + (member.member_id))
                .into(holder.memberPicture)
        holder.memberPace.text = calculatePace(member).toString()
    }

    override fun getItemCount(): Int = members.size

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val memberId: TextView = view.findViewById(R.id.memberId)
        val memberPicture: ImageView = view.findViewById(R.id.memberPicture)
        val memberFirstName: TextView = view.findViewById(R.id.memberFirstName)
        val memberLastName: TextView = view.findViewById(R.id.memberLastName)
        val memberPace: TextView = view.findViewById(R.id.memberPace)

        override fun toString(): String {
            return super.toString()
       }
    }

    fun calculatePace(member: Member): Float{
        return member.member_active_minutes / member.member_distance_covered
    }
}