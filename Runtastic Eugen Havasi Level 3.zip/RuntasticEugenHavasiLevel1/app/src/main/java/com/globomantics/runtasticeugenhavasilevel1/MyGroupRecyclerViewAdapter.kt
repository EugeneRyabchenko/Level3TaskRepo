package com.globomantics.runtasticeugenhavasilevel1

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.FragmentActivity
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.findNavController
import com.globomantics.runtasticeugenhavasilevel1.models.Group
import com.squareup.picasso.Picasso


class MyGroupRecyclerViewAdapter(
        private val act: FragmentActivity?,
        private var groups: List<Group>
        )
    : RecyclerView.Adapter<MyGroupRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.fragment_group, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val group = groups[position]
        holder.groupName.text = group.group_name
        holder.groupSize.text = group.members.size.toString()
        val groupPictureUrl: String = "http://download.runtastic.com/meetandcode/mobile_and_web_2016/images/groups/"
        Picasso.get()
            .load(groupPictureUrl + (group.group_id))
            .into(holder.groupPicture)
        holder.groupThumbnail.setOnClickListener{
            onToMembersClick(group.group_id, group.group_name)
        }
    }

    fun onToMembersClick(group_id: Int, group_name: String){
        val action = GroupFragmentDirections.actionGroupFragmentToMemberFragment(group_id, group_name)
        act?.findNavController(R.id.nav_container)?.navigate(action)
    }

    override fun getItemCount(): Int = groups.size

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val groupSize: TextView = view.findViewById(R.id.groupSize)
        val groupName: TextView = view.findViewById(R.id.groupName)
        val groupPicture: ImageView = view.findViewById(R.id.groupPicture)
        val groupThumbnail: Button = view.findViewById(R.id.groupThumbnail)

        override fun toString(): String {
            return super.toString()
        }
    }
}