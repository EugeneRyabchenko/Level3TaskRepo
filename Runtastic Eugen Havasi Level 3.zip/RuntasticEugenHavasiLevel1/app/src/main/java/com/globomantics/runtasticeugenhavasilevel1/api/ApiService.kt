package com.globomantics.runtasticeugenhavasilevel1.api


import com.globomantics.runtasticeugenhavasilevel1.models.Competition
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

fun createApiService(): ApiService {
    val retrofit = Retrofit.Builder()
        .baseUrl("https://codingcontest.runtastic.com/mobile_and_web_2016/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    return retrofit.create(ApiService::class.java)
}

interface ApiService {

    @GET("groups.json")
    fun getGroups(): Call<Competition>

}


