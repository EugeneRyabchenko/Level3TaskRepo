package com.globomantics.runtasticeugenhavasilevel1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.globomantics.runtasticeugenhavasilevel1.api.createApiService
import com.globomantics.runtasticeugenhavasilevel1.models.Competition
import com.globomantics.runtasticeugenhavasilevel1.models.Group
import com.globomantics.runtasticeugenhavasilevel1.models.Member
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apiService = createApiService()

        apiService.getGroups().enqueue(object : Callback<Competition> {
            override fun onResponse(call: Call<Competition>, response: Response<Competition>) {
                val c: Competition = response.body()!!
                calculateAndPrint(c)

            }

            override fun onFailure(call: Call<Competition>, t: Throwable) {
                // handle failure
                println("ERROR")
            }
        })

    }

    fun calculateAndPrint(competition: Competition){
        level1Task(competition)
        level2Task(competition)
    }

    fun level1Task(competition: Competition){

        val groupSizes = competition.groups.map { it.members.size }
        println("Biggest group size is: " + groupSizes.maxOrNull())

        var allMembers = competition.groups.map { it.members }.flatten()

        var fastestMember = allMembers.get(0)
        for (m in allMembers) {
            val bestPace = fastestMember.member_active_minutes / fastestMember.member_distance_covered
            val currentPace = m.member_active_minutes / m.member_distance_covered
            if (bestPace > currentPace){
                fastestMember = m
            }
        }
        println("Fastest Member's Id: " + fastestMember.member_id)
    }

    fun level2Task(competition: Competition){
        competition.groups.forEach { printSlowestTBMember(calcaluteTrainingBuddies(it)) }
    }



    fun calcaluteTrainingBuddies(group: Group): ArrayList<ArrayList<Member>> {
        val members = ArrayList(group.members)
        members.sortBy { calculatePace(it) }
        members.forEach { println(calculatePace(it)) }

        val groupTrainingBuddies: ArrayList<ArrayList<Member>> = ArrayList()
        for ((i, m) in members.withIndex()) {
            if(i < (members.size - 1) ){
                val mNext = members[i + 1]
                if ((calculatePace(mNext) - calculatePace(m)) <= 1){
                    val trainingBuddies: ArrayList<Member> = ArrayList()
                    trainingBuddies.add(m)
                    trainingBuddies.add(mNext)

                    var j = i+2
                    while (j < (members.size - 1) ){
                        val mAdditional = members[j]
                        if ((calculatePace(mAdditional) - calculatePace(m)) <= 1){
                            trainingBuddies.add(mAdditional)
                        }
                        j++
                    }

                    groupTrainingBuddies.add(trainingBuddies)
                }
            }
        }

        return groupTrainingBuddies
    }

    fun printSlowestTBMember(groupTrainingBuddies: ArrayList<ArrayList<Member>>){
        if(groupTrainingBuddies.size < 1){
            println("No Training Buddies")
            println("Slowest runner: -1")
        }else{
            val fastestTrainingBuddies = groupTrainingBuddies.get(0)
            println("Fastest Training Buddies: " + fastestTrainingBuddies)
            val slowestTrainingBuddy = fastestTrainingBuddies.get(fastestTrainingBuddies.size - 1)
            println("Slowest Training Buddy: " + slowestTrainingBuddy.member_id)
        }
    }

    fun calculatePace(member: Member): Float{
        return member.member_active_minutes / member.member_distance_covered
    }


}